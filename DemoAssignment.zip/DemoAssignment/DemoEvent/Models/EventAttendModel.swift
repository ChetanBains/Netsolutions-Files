//
//  EventAttendModel.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import Foundation

// MARK :- Struct Declaration

struct EventAttendModel {
    
    let lblEventAttendModelTop    : String
    let lblEventAttendModelMiddle : String
    let lblEventAttendModelBottom : String
    let imgEventAttendModel       : String
    
}

//  MARK :- Array Element Declaration

var eventAttend1 = EventAttendModel(
    lblEventAttendModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventAttendModelMiddle: "Lakers vs Celtics Soccer Fundraiser for the City",
    lblEventAttendModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventAttendModel: "party")

var eventAttend2 = EventAttendModel(
    lblEventAttendModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventAttendModelMiddle: "Soccer Fundraiser for the City of Masacusettes and Detroit",
    lblEventAttendModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventAttendModel: "party")

var eventAttend3 = EventAttendModel(
    lblEventAttendModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventAttendModelMiddle: "Soccer Fundraiser for the City of Masacusettes and Detroit",
    lblEventAttendModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventAttendModel: "party")

var eventAttend4 = EventAttendModel(
    lblEventAttendModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventAttendModelMiddle: "Soccer Fundraiser for the City of Masacusettes and Detroit",
    lblEventAttendModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventAttendModel: "party")

var eventAttend5 = EventAttendModel(
    lblEventAttendModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventAttendModelMiddle: "Soccer Fundraiser for the City of Masacusettes and Detroit",
    lblEventAttendModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventAttendModel: "party")

var eventAttend6 = EventAttendModel(
    lblEventAttendModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventAttendModelMiddle: "Soccer Fundraiser for the City of Masacusettes and Detroit",
    lblEventAttendModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventAttendModel: "party")

var eventAttend7 = EventAttendModel(
    lblEventAttendModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventAttendModelMiddle: "Soccer Fundraiser for the City of Masacusettes and Detroit",
    lblEventAttendModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventAttendModel: "party")

//  MARK :- Array Declaration

let eventAttendArray = [eventAttend1,eventAttend2,eventAttend3,eventAttend4,eventAttend5,eventAttend6,eventAttend7]

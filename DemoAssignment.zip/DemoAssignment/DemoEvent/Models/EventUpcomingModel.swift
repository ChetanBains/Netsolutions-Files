//
//  EventUpcomingModel.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import Foundation

// MARK :- Struct Declaration

struct EventUpcomingModel{
    
    let lblEventUpcomingModelTop : String
    let lblEventUpcomingModelMiddle : String
    let lblEventUpcomingModelBottom : String
    let imgEventUpcomingModel : String
}

//  MARK :- Array Element Declaration

var eventUpcoming1 = EventUpcomingModel(
    lblEventUpcomingModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventUpcomingModelMiddle: "Celtics vs Lakers",
    lblEventUpcomingModelBottom: "At Staples Centre - 20.5K Attending",
    imgEventUpcomingModel: "party")


var eventUpcoming2 = EventUpcomingModel(
    lblEventUpcomingModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventUpcomingModelMiddle: "Knicks vs Lakers",
    lblEventUpcomingModelBottom: "At MSG Garden - 10.5K Attending",
    imgEventUpcomingModel: "party")


var eventUpcoming3 = EventUpcomingModel(
    lblEventUpcomingModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventUpcomingModelMiddle: "Warriors vs Cleveland",
    lblEventUpcomingModelBottom: "At Oracle Arena - 21.0K Attending",
    imgEventUpcomingModel: "party")

var eventUpcoming4 = EventUpcomingModel(
    lblEventUpcomingModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventUpcomingModelMiddle: "Soccer Fundraiser for the City",
    lblEventUpcomingModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventUpcomingModel: "party")

var eventUpcoming5 = EventUpcomingModel(
    lblEventUpcomingModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventUpcomingModelMiddle: "Masacusettes and Detroit",
    lblEventUpcomingModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventUpcomingModel: "party")

var eventUpcoming6 = EventUpcomingModel(
    lblEventUpcomingModelTop: "FRI, JUN 7  @ 11 AM - 5PM",
    lblEventUpcomingModelMiddle: "Masacusettes and Detroit",
    lblEventUpcomingModelBottom: "At Montrose Park - 1.5K Attending",
    imgEventUpcomingModel: "party")


//  MARK :- Array Declaration


let eventUpcomingArray = [eventUpcoming1,eventUpcoming2,eventUpcoming3,eventUpcoming4,eventUpcoming5,eventUpcoming6]


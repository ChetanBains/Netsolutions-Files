//
//  FilterArrayModel.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 13/04/21.
//

import Foundation

struct FilterArrayModel{
    var filterManageArray   : [EventManageModel]
    var filterAttendArray   : [EventAttendModel]
    var filterUpcomingArray : [EventUpcomingModel]
    
    init(filterManageArray :  [EventManageModel],filterAttendArray:[EventAttendModel],filterUpcomingArray:[EventUpcomingModel]) {
        self.filterManageArray = filterManageArray
        self.filterAttendArray = filterAttendArray
        self.filterUpcomingArray = filterUpcomingArray
    }
}






import Foundation

// MARK :- Struct Declaration

struct EventManageModel{

    let lblEventManageModel : String
    var imgEventManageModel : String
    
}

// MARK :- Array Element Declaration

var eventManage1 = EventManageModel(
    lblEventManageModel: "ASPACA Adoption Shelter",
    imgEventManageModel: "images")

var eventManage2 = EventManageModel(
    lblEventManageModel: "ASPACA Adoption Shelter",
    imgEventManageModel: "images")

var eventManage3 = EventManageModel(
    lblEventManageModel: "ASPACA Adoption Shelter",
    imgEventManageModel: "images")

var eventManage4 = EventManageModel(
    lblEventManageModel: "ASPACA Adoption Shelter",
    imgEventManageModel: "images")

var eventManage5 = EventManageModel(
    lblEventManageModel: "ASPACA Adoption Shelter",
    imgEventManageModel: "images")

var eventManage6 = EventManageModel(
    lblEventManageModel: "ASPACA Adoption Shelter",
    imgEventManageModel: "images")


// MARK :- Array Declaration

 let eventManageArray = [eventManage1,eventManage2,eventManage3,eventManage4,eventManage5,eventManage6]


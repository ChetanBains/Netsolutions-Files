//
//  EventUpcoming.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import UIKit

class EventUpcoming: UITableViewCell {
    
    var upcomingObj = ViewController()
    // CollectionView Outlets
    
    @IBOutlet var imgUpcoming : UIImageView!
    @IBOutlet var lblUpcoming1 : UILabel!
    @IBOutlet var lblUpcoming2 : UILabel!
    @IBOutlet var lblUpcoming3 : UILabel!
    @IBOutlet var btnRegister : UIButton!
    @IBOutlet var btnInterested : UIButton!
    
    // Xib Identifier
    
    static func nib() -> UINib{
        return UINib(nibName: "EventUpcoming", bundle: nil)
    }

    
    var upcomingEvents : EventUpcomingModel? {
        didSet {
            populateData ()
        }
    }
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Customization of CollectionView Elements
        
        imgUpcoming.layer.cornerRadius = 20
        imgUpcoming.clipsToBounds = true
        btnRegister.layer.cornerRadius = 10
        btnRegister.clipsToBounds = true
        btnInterested.layer.cornerRadius = 10
        btnInterested.clipsToBounds = true

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func populateData () {
        imgUpcoming.image = UIImage(named: upcomingEvents?.imgEventUpcomingModel ?? "")
        lblUpcoming1.text = upcomingEvents?.lblEventUpcomingModelTop ?? ""
        lblUpcoming2.text = upcomingEvents?.lblEventUpcomingModelMiddle ?? ""
        lblUpcoming3.text = upcomingEvents?.lblEventUpcomingModelBottom ?? ""
    }
    
    // CollectionView Button Elements
    
    @IBAction func btnManageInteresed(){
        
    }
    @IBAction func btnManageRegister(){
        
    }
    

    
}






import UIKit

class EventManagerTableCell: UITableViewCell {
    
    let objView = ViewController()
    var noOfRowManage : Int?
    
    // CollectionView Outlet

    @IBOutlet var collectionViewEventManager : UICollectionView!
    
    // Xib Identifier
    
    static func nib() -> UINib{
        return UINib(nibName: "EventManagerTableCell", bundle: nil)
    }
    
    var arrManagedEvents : [EventManageModel]? {
        didSet {
            collectionViewEventManager.reloadData()
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        // CollectionView Addons
        
        collectionViewEventManager.delegate = self
        collectionViewEventManager.dataSource = self
        collectionViewEventManager.contentInsetAdjustmentBehavior = .never
        collectionViewEventManager.keyboardDismissMode = .onDrag
        collectionViewEventManager.reloadData()
        // Xib Register CollectionView
        
        collectionViewEventManager.register(UINib(nibName: "EventManagerCollectionCell", bundle: nil), forCellWithReuseIdentifier: "EventManagerCollectionCell")
        
//        if let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout,
//                   let collectionView = collectionView {
//                    let w = collectionView.frame.width - 20
//                    flowLayout.estimatedItemSize = CGSize(width: w, height: 200)
//        }
    }


    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // Event Add "+" Button
    @IBAction func btnAttendViewAll(){
        
    }
    
}

//  MARK :- CollectionView Protocols

extension EventManagerTableCell : UICollectionViewDelegateFlowLayout,UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrManagedEvents?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       guard let cell = collectionViewEventManager.dequeueReusableCell(withReuseIdentifier: "EventManagerCollectionCell", for: indexPath) as? EventManagerCollectionCell else {fatalError("Error to create TableViewCell")}
        
        cell.managedEvents = arrManagedEvents?[indexPath.row]
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionViewEventManager.frame.size.width/2.3, height: 130)
    }
    
    
}


import UIKit

class UpcomingTitleTableCell: UITableViewCell {
    
    // TableViewCell Outlets
    
    @IBOutlet var lblUpcomingTitle : UILabel!
    
    // Xib Identifier
    
    static func nib() -> UINib{
        return UINib(nibName: "UpcomingTitleTableCell", bundle: nil)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

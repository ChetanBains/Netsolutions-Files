

import UIKit

class EventAttendTableCell: UITableViewCell {
    
    var objViewAttend = ViewController()
    var noOfRowAttend : Int?
    
    // CollectionView Outlet

    @IBOutlet var collectionViewEventAttend: UICollectionView!

    // Xib Identifier
    
    static func nib() -> UINib{
        return UINib(nibName: "EventAttendTableCell", bundle: nil)
    }
    
    var arrAttendEvents : [EventAttendModel]? {
        didSet {
            collectionViewEventAttend.reloadData()
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        
        // CollectionView Addons
        
        collectionViewEventAttend.delegate = self
        collectionViewEventAttend.dataSource = self
        self.collectionViewEventAttend.contentInsetAdjustmentBehavior = .never
        collectionViewEventAttend.keyboardDismissMode = .onDrag
        collectionViewEventAttend.reloadData()
        
        // Xib Register
        collectionViewEventAttend.register(UINib(nibName: "EventAttendCollectionCell", bundle: nil), forCellWithReuseIdentifier: "EventAttendCollectionCell")
        
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // View All Button
    
    @IBAction func btnAttendViewAll(){
        
    }
    
  
}

//  MARK :- CollectionView Protocols

extension EventAttendTableCell : UICollectionViewDelegateFlowLayout,UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        return arrAttendEvents?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionViewEventAttend.dequeueReusableCell(withReuseIdentifier: "EventAttendCollectionCell", for: indexPath) as? EventAttendCollectionCell else {fatalError("Error to create TableViewCell")}
        
        cell.attendEvents = arrAttendEvents?[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionViewEventAttend.frame.size.width/1.1, height: 240)
    }


}
    
    

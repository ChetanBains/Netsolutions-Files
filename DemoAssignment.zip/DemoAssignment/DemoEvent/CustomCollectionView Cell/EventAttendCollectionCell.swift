//
//  EventAttendCollectionCell.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import UIKit

class EventAttendCollectionCell: UICollectionViewCell {
    
    @IBOutlet var imgAttend : UIImageView!
    @IBOutlet var lblAttend1 : UILabel!
    @IBOutlet var lblAttend2 : UILabel!
    @IBOutlet var lblAttend3 : UILabel!
    
    static func nib() -> UINib{
        return UINib(nibName: "EventAttendCollectionCell", bundle: nil)
    }
    
    var attendEvents : EventAttendModel? {
        didSet {
            populateData ()
        }
    }


    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgAttend.layer.cornerRadius = 20
        imgAttend.clipsToBounds = true
    }
    func populateData () {
        imgAttend.image = UIImage(named: attendEvents?.imgEventAttendModel ?? "")
        lblAttend1.text = attendEvents?.lblEventAttendModelTop ?? ""
        lblAttend2.text = attendEvents?.lblEventAttendModelMiddle ?? ""
        lblAttend3.text = attendEvents?.lblEventAttendModelBottom ?? ""
    }

}

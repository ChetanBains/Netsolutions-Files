//
//  EventManagerCollectionCell.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import UIKit

class EventManagerCollectionCell: UICollectionViewCell {
    
    @IBOutlet var imgManage : UIImageView!
    @IBOutlet var lblManage1 : UILabel!
   
    
    static func nib() -> UINib{
        return UINib(nibName: "EventManagerCollectionCell", bundle: nil)
    }

    var managedEvents : EventManageModel? {
        didSet {
            populateData ()
        }
    }
//    override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
//            setNeedsLayout()
//            layoutIfNeeded()
//            let size = contentView.systemLayoutSizeFitting(layoutAttributes.size)
//            var frame = layoutAttributes.frame
//            frame.size.height = ceil(size.height)
//            layoutAttributes.frame = frame
//            return layoutAttributes
//        }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgManage.layer.cornerRadius = 20
        imgManage.clipsToBounds = true
    }
    func populateData () {
        imgManage.image = UIImage(named: managedEvents?.imgEventManageModel ?? "")
        lblManage1.text = managedEvents?.lblEventManageModel ?? ""
    }

}



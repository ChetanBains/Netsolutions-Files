

import UIKit


class ViewController: UIViewController,UIGestureRecognizerDelegate{

    //Variables
    
    var myData = [FilterArrayModel]()
    var numberOfRows : Int?
    var numberOfSections : Int?
    var heightOfSection : CGFloat?
    var filteredManageArray = [EventManageModel]()
    var filteredAttendArray = [EventAttendModel]()
    var filteredUpcomingArray = [EventUpcomingModel]()
    


    
    //  MARK :-  ViewController Outlets
    
    @IBOutlet var searchBar : UISearchBar!
    @IBOutlet var tableView : UITableView!
    @IBOutlet weak var tableViewBottomConstraints: NSLayoutConstraint!

        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Navigation Controller Addons
        
        navigationController?.navigationBar.prefersLargeTitles = true
        
        // TableView Addons
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.contentInsetAdjustmentBehavior = .never
        filteredManageArray = [eventManage1,eventManage2,eventManage3,eventManage4,eventManage5,eventManage6]
        filteredAttendArray = [eventAttend1,eventAttend2,eventAttend3,eventAttend4,eventAttend5,eventAttend6,eventAttend7]
        filteredUpcomingArray = [eventUpcoming1,eventUpcoming2,eventUpcoming3,eventUpcoming4,eventUpcoming5,eventUpcoming6]
        

        
        // TableView Frame Customization

//        var frame = CGRect.zero
//        var frameTop = CGRect.zero
//        //frame.size.height = .leastNormalMagnitude
//        frameTop.size.height = 20
//        frameTop.size.width = tableView.frame.size.width
//        tableView.tableHeaderView = UIView(frame: frameTop)
//        tableView.tableFooterView = UIView(frame: frame)
//        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: -tableView.bounds.height, right: 0)

        
        // Xib Register

        self.tableView.register(UINib(nibName: "EventManagerTableCell", bundle: nil), forCellReuseIdentifier: "EventManagerXib")
        self.tableView.register(UINib(nibName: "EventAttendTableCell", bundle: nil), forCellReuseIdentifier: "EventAttendXib")
        self.tableView.register(UINib(nibName: "EventUpcoming", bundle: nil), forCellReuseIdentifier: "EventUpcomingXib")
        self.tableView.register(UINib(nibName: "UpcomingTitleTableCell", bundle: nil), forCellReuseIdentifier: "UpcomingTitleTableCell")
        
        NotificationCenter.default.addObserver(self,
                    selector: #selector(keyboardWillShow(sender:)),
                    name: UIResponder.keyboardWillShowNotification,
                    object: nil)
        NotificationCenter.default.addObserver(self,
                    selector: #selector(keyboardWillHide(sender:)),
                    name: UIResponder.keyboardWillHideNotification,
                    object: nil)
        
        searchBar.delegate = self
        searchBar.showsCancelButton = false
        tableView.keyboardDismissMode = .onDrag

        

    }
    
    //  Keyboard Function
    
    @objc func keyboardWillShow(sender: NSNotification) {
        let keyboardSize = (sender.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.height
        
        tableViewBottomConstraints.constant = keyboardSize

        let duration: TimeInterval = (sender.userInfo![UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue

        UIView.animate(withDuration: duration) { self.view.layoutIfNeeded() }
    }

    @objc func keyboardWillHide(sender: NSNotification) {
        
        let duration: TimeInterval = (sender.userInfo![UIResponder.keyboardAnimationDurationUserInfoKey] as! NSNumber).doubleValue
        tableViewBottomConstraints.constant = 0

        UIView.animate(withDuration: duration) { self.view.layoutIfNeeded() }
    }

    
    @IBAction func addTappedPlus(){
        
    }
}

// MARK :- TableView Protocols

extension ViewController : UITableViewDataSource,UITableViewDelegate{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        numberOfSections = 4
        return numberOfSections!
        
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            
            if section == 0 {
                numberOfRows = 1
            }
            if section == 1{
                numberOfRows = 1
            }
            if section == 2{
                numberOfRows = 1
            }
            if section == 3{
                numberOfRows = filteredUpcomingArray.count
            }
        return numberOfRows!
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
            if (indexPath.section == 0 && !filteredManageArray.isEmpty){
                heightOfSection = 180
            }
            else if (indexPath.section == 1 && !filteredAttendArray.isEmpty){
                heightOfSection = 350
            }
            else if (indexPath.section == 2 && !filteredUpcomingArray.isEmpty){
                heightOfSection = 50
            }
            else if (indexPath.section == 3 && !filteredUpcomingArray.isEmpty){
                heightOfSection = 232
            }
            else if (indexPath.section == 0 && filteredManageArray.isEmpty){
                heightOfSection = 0
            }
            else if (indexPath.section == 1 && filteredAttendArray.isEmpty){
                heightOfSection = 0
            }
            else if indexPath.section == 2 && filteredUpcomingArray.isEmpty{
                heightOfSection = 0
            }
            else if (indexPath.section == 3 && filteredManageArray.isEmpty){
                heightOfSection = 0
            }
        return heightOfSection!
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

            if (indexPath.section == 0){
           
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "EventManagerXib",for: indexPath) as? EventManagerTableCell else {fatalError("Error to create TableViewCell")}
                cell.arrManagedEvents = filteredManageArray
                return cell
            }
            else if (indexPath.section == 1){
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "EventAttendXib",for: indexPath) as? EventAttendTableCell else {fatalError("Error to create TableViewCell")}
                cell.arrAttendEvents = filteredAttendArray
                return cell
            }
            else if (indexPath.section == 2){
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "UpcomingTitleTableCell",for: indexPath) as? UpcomingTitleTableCell else {fatalError("Error to create TableViewCell")}
            cell.lblUpcomingTitle.text = "Upcoming Events"

                return cell
            }
            else {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "EventUpcomingXib", for: indexPath) as? EventUpcoming else {fatalError("Error to create TableViewCell")}
                cell.upcomingEvents = filteredUpcomingArray[indexPath.row]
                return cell
            }
        }
}
    
    // SearchBar Delegate Methods

extension ViewController :UISearchBarDelegate,UISearchDisplayDelegate{
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.searchBar.showsCancelButton = true;

        
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {

        self.searchBar.showsCancelButton = false
        filteredManageArray = [eventManage1,eventManage2,eventManage3,eventManage4,eventManage5,eventManage6]
        filteredAttendArray = [eventAttend1,eventAttend2,eventAttend3,eventAttend4,eventAttend5,eventAttend6,eventAttend7]
        filteredUpcomingArray = [eventUpcoming1,eventUpcoming2,eventUpcoming3,eventUpcoming4,eventUpcoming5,eventUpcoming6]
        searchBar.text?.removeAll()
        self.searchBar.endEditing(true)
        self.tableView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let text = searchBar.text else {return print("No Input in Search Bar")}
            filteredUpcomingArray = eventUpcomingArray.filter{ ($0.lblEventUpcomingModelMiddle.localizedCaseInsensitiveContains(text)) }
            filteredAttendArray = eventAttendArray.filter{($0.lblEventAttendModelMiddle.localizedCaseInsensitiveContains(text))}
            filteredManageArray = eventManageArray.filter{($0.lblEventManageModel.localizedCaseInsensitiveContains(text))}
            self.tableView.reloadData()
            self.searchBar.endEditing(true)
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        tableView.frame = CGRect(x: 20, y: 20, width: tableView.frame.size.width, height: tableView.frame.size.width - 400)
        guard let text = searchBar.text else {return print("No Input in Search Bar")}
            filteredUpcomingArray = eventUpcomingArray.filter{ ($0.lblEventUpcomingModelMiddle.localizedCaseInsensitiveContains(text)) }
            filteredAttendArray = eventAttendArray.filter{($0.lblEventAttendModelMiddle.localizedCaseInsensitiveContains(text))}
            filteredManageArray = eventManageArray.filter{($0.lblEventManageModel.localizedCaseInsensitiveContains(text))}
        print("Filtered Manage Array : \(filteredManageArray.count)")
        print("Filtered Attend Array : \(filteredAttendArray.count)")
        print("Filtered Upcoming Array : \(filteredUpcomingArray.count)")
            self.tableView.reloadData()
        
    }
}



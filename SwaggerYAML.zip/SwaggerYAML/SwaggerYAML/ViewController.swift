//
//  ViewController.swift
//  SwaggerYAML
//
//  Created by Chetanjeev Singh Bains on 01/04/21.
//

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let obj = JSONPlaceholderResourcePostAPI.postsGet
    }
    


}


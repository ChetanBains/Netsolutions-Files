

import Foundation

struct Value{
    
    var number : Int 
}


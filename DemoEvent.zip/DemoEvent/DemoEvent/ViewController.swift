//
//  ViewController.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 07/04/21.
//

import UIKit


class ViewController: UIViewController {
    
    
    @IBOutlet var searchBar : UISearchBar!
    @IBOutlet var tableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        navigationController?.navigationBar.prefersLargeTitles = true
        tableView.dataSource = self
        tableView.delegate = self

        self.tableView.register(UINib(nibName: "EventManagerTableCell", bundle: nil), forCellReuseIdentifier: "EventManagerXib")
        self.tableView.register(UINib(nibName: "EventAttendTableCell", bundle: nil), forCellReuseIdentifier: "EventAttendXib")
        self.tableView.register(UINib(nibName: "EventUpcoming", bundle: nil), forCellReuseIdentifier: "EventUpcomingXib")
        //self.scrollView.contentInsetAdjustmentBehavior = .never
        
        self.tableView.contentInsetAdjustmentBehavior = .never

        self.tableView.reloadData()
    }
    

    @IBAction func addTappedPlus(){
        
    }
}

extension ViewController : UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        3
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        if indexPath.row == 0{
            return 180
        }
        else if indexPath.row == 1{
            return 300
        }
        else{
            return 350
        }

     }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 0 {
           
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "EventManagerXib",for: indexPath) as? EventManagerTableCell else {fatalError("Error to create TableViewCell")}
            return cell
        }
        else if indexPath.row == 1 {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "EventAttendXib", for: indexPath) as? EventAttendTableCell else {fatalError("Error to create TableViewCell")}
            return cell
        }
        else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "EventUpcomingXib", for: indexPath) as? EventUpcoming else {fatalError("Error to create TableViewCell")}
            return cell
        }
    }
    

    

}

//extension ViewController : UISearchBarDelegate,UISearchDisplayDelegate{
//    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
//        guard let searchBarText = searchBar.text else {return}
//        let searchTest = EventManageModel.init(name: searchBar)
//}
//




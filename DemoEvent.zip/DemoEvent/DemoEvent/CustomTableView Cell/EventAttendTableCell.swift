//
//  EventAttendTableCell.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 07/04/21.
//

import UIKit

class EventAttendTableCell: UITableViewCell {

 
    @IBOutlet var collectionViewEventAttend: UICollectionView!
    
    static func nib() -> UINib{
        return UINib(nibName: "EventAttendTableCell", bundle: nil)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionViewEventAttend.delegate = self
        collectionViewEventAttend.dataSource = self
        self.collectionViewEventAttend.contentInsetAdjustmentBehavior = .never
        collectionViewEventAttend.register(UINib(nibName: "EventAttendCollectionCell", bundle: nil), forCellWithReuseIdentifier: "EventAttendCollectionCell")
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnAttendViewAll(){
        
    }
    
  
}

extension EventAttendTableCell : UICollectionViewDelegateFlowLayout,UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionViewEventAttend.dequeueReusableCell(withReuseIdentifier: "EventAttendCollectionCell", for: indexPath) as? EventAttendCollectionCell else {fatalError("Error to create TableViewCell")}
        
        cell.imgAttend.image = UIImage(named: "party")
        cell.lblAttend1.text = "FRI, JUN 7  @ 11 AM - 5PM"
        cell.lblAttend2.text = "Soccer Fundraiser for the City"
        cell.lblAttend3.text = "At Montrose Park - 1.5K Attending"
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        20
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        20
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width: 370, height: 240)
    }


}
    
    

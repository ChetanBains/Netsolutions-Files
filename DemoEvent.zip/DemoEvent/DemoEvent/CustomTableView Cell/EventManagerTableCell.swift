//
//  EventManagerTableCell.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 07/04/21.
//

import UIKit

class EventManagerTableCell: UITableViewCell {

    @IBOutlet var collectionViewEventManager: UICollectionView!
    
    static func nib() -> UINib{
        return UINib(nibName: "EventManagerTableCell", bundle: nil)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionViewEventManager.delegate = self
        collectionViewEventManager.dataSource = self
        self.collectionViewEventManager.contentInsetAdjustmentBehavior = .never
        collectionViewEventManager.register(UINib(nibName: "EventManagerCollectionCell", bundle: nil), forCellWithReuseIdentifier: "EventManagerCollectionCell")
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnAttendViewAll(){
        
    }
    
}
extension EventManagerTableCell : UICollectionViewDelegateFlowLayout,UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       guard let cell = collectionViewEventManager.dequeueReusableCell(withReuseIdentifier: "EventManagerCollectionCell", for: indexPath) as? EventManagerCollectionCell else {fatalError("Error to create TableViewCell")}
        
        cell.imgManage.image = UIImage(named: "party")
        cell.lblManage1?.text = "Adoption"
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        20
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        20
    }
    


    
    
}

//
//  EventUpcoming.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import UIKit

class EventUpcoming: UITableViewCell {
    

    
    @IBOutlet var collectionViewEventUpcoming: UICollectionView!
    
    static func nib() -> UINib{
        return UINib(nibName: "EventUpcoming", bundle: nil)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionViewEventUpcoming.delegate = self
        collectionViewEventUpcoming.dataSource = self
        self.collectionViewEventUpcoming.contentInsetAdjustmentBehavior = .never
        collectionViewEventUpcoming.register(UINib(nibName: "EventUpcomingrCollectionCell", bundle: nil), forCellWithReuseIdentifier: "EventUpcomingrCollectionCell")

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    

    
}
extension EventUpcoming : UICollectionViewDelegateFlowLayout,UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionViewEventUpcoming.dequeueReusableCell(withReuseIdentifier: "EventUpcomingrCollectionCell", for: indexPath) as? EventUpcomingrCollectionCell else{fatalError("Error to create TableViewCell")}
        
        cell.imgUpcoming.image = UIImage(named: "party")
        cell.lblUpcoming1.text = "FRI, JUN 7  @ 11 AM - 5PM"
        cell.lblUpcoming2.text = "Soccer Fundraiser for the City"
        cell.lblUpcoming3.text = "At Montrose Park - 1.5K Attending"
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        40
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        40
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width: 370, height: 250)
    }
}

//
//  EventAttendModel.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import Foundation

struct EventAttendModel{
    
}

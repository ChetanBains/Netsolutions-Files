//
//  EventManageModel.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import Foundation

struct EventManageModel{

    let centres = ["Adoption US","Adoption IN","Adoption JAP","Adoption IR","Adoption ENG","Adoption CAN"]
    
    
}

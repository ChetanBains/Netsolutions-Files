//
//  EventAttendCollectionCell.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import UIKit

class EventAttendCollectionCell: UICollectionViewCell {
    
    @IBOutlet var imgAttend : UIImageView!
    @IBOutlet var lblAttend1 : UILabel!
    @IBOutlet var lblAttend2 : UILabel!
    @IBOutlet var lblAttend3 : UILabel!
    
    static func nib() -> UINib{
        return UINib(nibName: "EventAttendCollectionCell", bundle: nil)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgAttend.layer.cornerRadius = 20
        imgAttend.clipsToBounds = true
        
        
    }

}

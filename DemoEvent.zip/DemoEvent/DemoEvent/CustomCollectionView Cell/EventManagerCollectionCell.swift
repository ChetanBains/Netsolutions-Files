//
//  EventManagerCollectionCell.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import UIKit

class EventManagerCollectionCell: UICollectionViewCell {
    
    @IBOutlet var imgManage : UIImageView!
    @IBOutlet var lblManage1 : UILabel!
    
    static func nib() -> UINib{
        return UINib(nibName: "EventManagerCollectionCell", bundle: nil)
    }


    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgManage.layer.cornerRadius = 20
        imgManage.clipsToBounds = true

        
    }

}



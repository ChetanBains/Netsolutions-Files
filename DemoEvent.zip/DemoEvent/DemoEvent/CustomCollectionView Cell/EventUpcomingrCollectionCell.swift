//
//  EventUpcomingrCollectionCell.swift
//  DemoEvent
//
//  Created by Chetanjeev Singh Bains on 08/04/21.
//

import UIKit

class EventUpcomingrCollectionCell: UICollectionViewCell {
    
    @IBOutlet var imgUpcoming : UIImageView!
    @IBOutlet var lblUpcoming1 : UILabel!
    @IBOutlet var lblUpcoming2 : UILabel!
    @IBOutlet var lblUpcoming3 : UILabel!
    @IBOutlet var btnRegister : UIButton!
    @IBOutlet var btnInterested : UIButton!
    
    
    static func nib() -> UINib{
        return UINib(nibName: "EventUpcomingrCollectionCell", bundle: nil)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgUpcoming.layer.cornerRadius = 20
        imgUpcoming.clipsToBounds = true
        btnRegister.layer.cornerRadius = 10
        btnRegister.clipsToBounds = true
        btnInterested.layer.cornerRadius = 10
        btnInterested.clipsToBounds = true
    }
    @IBAction func btnManageInteresed(){
        
    }
    @IBAction func btnManageRegister(){
        
    }

}

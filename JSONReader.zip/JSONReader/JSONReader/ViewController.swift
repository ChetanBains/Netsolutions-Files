//
//  ViewController.swift
//  JSONReader
//
//  Created by Chetanjeev Singh Bains on 10/03/21.
//

import UIKit
import Foundation
import SwiftyJSON

// ***** MARK :- Adding a Structure to Data *****

struct JSONData {
    var row             : Int?
    var cellPhoneNumber : String?
    var emailAddress    : String?
    var name            : String?
    var profileImage    : String?
    var receiverID      : Int?
    var receiverType    : String?
    
    init() {}
    init(playerObj : JSONData){}
}



class ViewController: UIViewController {
    
    var arr = [JSONData]()
    
    @IBOutlet weak var tableView : UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ReadJSON()
    }
    
    // ***** MARK :- Loading JSON File *****
    
    func ReadJSON(){
        
        // Link JSON File
        
        guard let fileUrl = Bundle.main.url(forResource: "GetPlayers", withExtension: "json")
        else {return print("Error reading file.")}
        
        do {
            let data = try Data(contentsOf: fileUrl)
            let jsonObject = try JSON(data: data)
            
        // Get data from file
        
            let dataArray = jsonObject["PlayerList"].arrayValue
            for entity in dataArray {
                
                var playerObj = JSONData()
                let rowEntity               = entity["row"].intValue
                let nameEntity              = entity["name"].stringValue
                let receiverIDEntity        = entity["receiverID"].intValue
                let receiverTypeEntity      = entity["receiverType"].stringValue
                let emailAddressEntity      = entity["emailAddress"].stringValue
                let cellPhoneNumberEntity   = entity["cellPhoneNumber"].stringValue
                let profileImageEntity      = entity["profileImage"].stringValue
                
                playerObj.row = rowEntity
                playerObj.name = nameEntity
                playerObj.receiverID = receiverIDEntity
                playerObj.receiverType = receiverTypeEntity
                playerObj.emailAddress = emailAddressEntity
                playerObj.cellPhoneNumber = cellPhoneNumberEntity
                playerObj.profileImage = profileImageEntity
                
//                let getContent = JSONData(row: rowEntity, cellPhoneNumber: cellPhoneNumberEntity, emailAddress: emailAddressEntity, name: nameEntity, profileImage: profileImageEntity, receiverID: receiverIDEntity, receiverType: receiverTypeEntity)
                    
                    arr.append(playerObj)
            }
            self.tableView.reloadData()
        }
        catch {
           print(error)
        }
    }
}

extension ViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            guard let cell  = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as? JSONTableViewCell else {return JSONTableViewCell()}
            
            let tableRow = arr[indexPath.row]
        cell.lblText!.text = String(tableRow.name!)
        
            return cell

    }
}
    

    




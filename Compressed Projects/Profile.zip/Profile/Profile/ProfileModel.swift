//
//  ProfileModel.swift
//  Profile
//
//  Created by Chetanjeev Singh Bains on 29/01/21.
//


import Foundation

public class ProfileModel {
  
    
    var FirstName : String!
    var LastName : String!
    var CompanyName : String!
    var UserName : String!
    var Email : String!
    
    

}
    

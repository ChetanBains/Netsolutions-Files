//
//  ViewController.swift
//  YamlSwift
//
//  Created by Chetanjeev Singh Bains on 02/04/21.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    let obj = CalendrificAPI()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

